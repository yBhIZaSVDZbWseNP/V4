from regis import *

@bot.on(events.CallbackQuery(data=b'change-limit-all'))
async def project(event):
	async def project_(event):
		inline = [
[Button.inline(" CHANGE IP SSH ","change-ssh"),
Button.inline(" CHANGE IP VMESS ","change-vmess")],
[Button.inline(" CHANGE IP VLESS ","change-vless"),
Button.inline(" CHANGE IP TROJAN ","change-trojan")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
   **🙈 MENU CHANGE LIMIT 🙈**
━━━━━━━━━━━━━━━━━━━━━━━ 
🌹 **» Service:** `SSH OVPN`
🌸 **» Hostname/IP:** `{DOMAIN}`
🌷 **» ISP:** `{z["isp"]}`
💐 **» Country:** `{z["country"]}`
🌾 **» @Andyyuda**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await project_(event)
	else:
		await event.answer("Access Denied",alert=True)
